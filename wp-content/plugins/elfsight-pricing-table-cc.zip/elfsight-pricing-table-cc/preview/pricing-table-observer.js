/*

Elfsight Pricing Table
Version: 1.0.0
Release date: Thu Oct 19 2017

https://elfsight.com

Copyright (c) 2017 Elfsight, LLC. ALL RIGHTS RESERVED

*/(window.eapps=window.eapps||{}).observer=function(a,i){a.$watch("widget.data.layout",function(a,n){var t=function(a){i.forEach(function(n,t){if("head"===n.id)return i[t].visible=a,!1})};"table"!==n?"table"===a&&t(!0):t(!1)})};