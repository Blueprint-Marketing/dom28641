( function( $ ) {
	
		$(".fancybox").fancybox();


} )( jQuery );
$(document).ready(function () {

	$('form#loginform .login-submit').after('<a href="/forgot-password" id="forgot">Forgot Password?</a>');
	$(".menu-item-has-children").addClass("clearfix");
	$('.usaHtml5MapStateInfo').bind("DOMNodeInserted DOMNodeRemoved", function(){
		window.scrollTo(0, $( ".usaHtml5MapStateInfo" ).offset().top - 100);
		console.log( $( ".usaHtml5MapStateInfo" ).offset().top );
	});
}); 


 